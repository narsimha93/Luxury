import { StyleSheet, Text, View, Alert } from "react-native";
import React, { useState } from "react";
import RegisterationForm from "../components/Forms/RegisterationForm";
import LoadingOverlay from "../components/UI/LoadingOverlay";
import axios from "axios";

const Register = () => {
  // const [isAuthentication, setAuthentication] = useState(false);
  async function signupHandler({
    username,
    email,
    firstname,
    lastname,
    password,
    confirmpassword,
  }) {
    //  setAuthentication(true);
    try {
      const userdata = {
        username: username,
        password: password,
        password2: confirmpassword,
        email: email,
        first_name: firstname,
        last_name: lastname,
      };
      const response = await fetch(
        "https://house-rent.herokuapp.com/accounts/registerapi/",
        {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(userdata),
        }
      );
      data = await response.json();

      if (response.status === 400) {
        if (data.email && data.username) {
          alert("Email:" + data.email + "\n" + "username: " + data.username);
        } else if (data.email) {
          alert("Email:" + data.email);
        } else if (data.username) {
          alert("Username" + data.username);
        } else {
          alert("PAssword length should be greater than 8");
        }
      } else {
        alert("Account Successfully Created");
      }

      //data = await response.json();
    } catch (error) {}
  }
  // if (isAuthentication) {
  //   return <LoadingOverlay message="Creating User ..." />;
  // }
  return <RegisterationForm onAuthenticate={signupHandler} />;
};

export default Register;

const styles = StyleSheet.create({});
