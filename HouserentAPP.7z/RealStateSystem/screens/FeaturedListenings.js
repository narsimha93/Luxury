import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  ScrollView,
  VirtualizedList,
} from "react-native";
import React, { useState, useEffect } from "react";
import Cards from "../components/UI/Cards";
import LoadingOverlay from "../components/UI/LoadingOverlay";
const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;

const FeaturedListenings = () => {
  const [data, setData] = useState([]);
  const [timeout, settime] = useState(true);
  const [isdata, setisdata] = useState(true);

  const fetchData = async () => {
    settime(true);
    try {
      const response = await fetch(
        "https://house-rent.herokuapp.com/listings/listing"
      );
      const data = await response.json();
      return data;
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    const getData = async () => {
      const data = await fetchData();
      // console.log(data[0].);
      setData(data);
    };
    getData();
  }, []);
  const renderItem = ({ item }) => {
    return (
      <View style={styles.container}>
        <Cards item={item} />
      </View>
    );
  };
  const getItem = (data, index) => {
    return data[index];
  };

  return (
    <View>
      {data.length === 0 ? (
        <LoadingOverlay />
      ) : (
        <VirtualizedList
          data={data}
          initialNumToRender={5}
          renderItem={renderItem}
          //onRefresh={}
          //  refreshing={timeout}
          keyExtractor={(item) => item.id}
          getItemCount={(data) => data.length}
          getItem={getItem}
        />
      )}
      {/* <ScrollView>
        <View style={styles.container}>
          <Cards />
        </View>
        <View style={styles.container}>
          <Cards />
        </View>
      </ScrollView> */}
    </View>
  );
};

export default FeaturedListenings;

const styles = StyleSheet.create({
  container: {
    width: windowWidth * 0.9,
    alignSelf: "center",
    marginTop: windowHeight * 0.02,
  },
});
