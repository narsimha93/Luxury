import {
  StyleSheet,
  Text,
  View,
  Pressable,
  Dimensions,
  ScrollView,
  Image,
  TextInput,
  Linking,
} from "react-native";
import React, { useEffect, useState, useContext, useRef } from "react";
import { useNavigation } from "@react-navigation/native";
const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;
import Slick from "react-native-slick";
//import Video from "react-native-video";
import { Video } from "expo-av";
import { AuthContext } from "../store/auth-context";
import axios from "axios";
import moment from "moment";
import {
  MaterialCommunityIcons,
  FontAwesome5,
  FontAwesome,
  Entypo,
} from "@expo/vector-icons";
import MakeInquiry from "../components/Forms/MakeInquiry";
import Transportation from "../components/Forms/Transportation";
import BookProperty from "../components/Forms/BookProperty";
import LoadingOverlay from "../components/UI/LoadingOverlay";

const MoreInfo = ({ route }) => {
  const wordFileUrl = `https://www.indiafilings.com/sample-format/residential-rental-agreement-format.doc`;

  console.log(route.params);

  const [data, setData] = useState(null);
  const [timeout, settime] = useState(true);
  const [isdata, setisdata] = useState(true);
  const authCtx = useContext(AuthContext);
  const navigation = useNavigation();
  const [modal1Visible, setModal1Visible] = useState(false);
  const [modal2Visible, setModal2Visible] = useState(false);
  const [modal3Visible, setModal3Visible] = useState(false);
  const [comment, SetComment] = useState("");
  const submit = async () => {
    const formData = {
      comment: comment,
      post: route.params.item.id,
      user: 2,
    };

    const response = await fetch(
      "https://house-rent.herokuapp.com/contacts/reviewapi/",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      }
    );
    const data = await response.json();
    if (response.status === 401) {
      console.log(data);
    } else {
      alert("Comment added");
      SetComment("");
    }
  };
  const fetchData = async () => {
    let isUnmounted = false;
    settime(true);
    const token = authCtx.token;
    await axios
      .get("https://house-rent.herokuapp.com/contacts/reviewapi/", {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      })
      .then(function (response) {
        if (!isUnmounted) {
          console.log(response.data);
          setData(response.data);
          setTimeout(() => {
            settime(false);
          }, 2500);
        }
      })
      .catch(function (error) {
        console.log(error);
      });
    return () => {
      isUnmounted = true;
    };
  };
  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    if (data == null || data == undefined || data.length == 0) {
      setisdata(false);
    } else {
      setisdata(true);
    }
  }, [isdata, data]);

  const openModal = (setModalVisible) => {
    setModalVisible(true);
  };

  const closeModal = (setModalVisible) => {
    setModalVisible(false);
  };

  var images = [];
  var size = 7;

  for (let i = 0; i <= size; i++) {
    if (i === 0) {
      images.push(
        <View style={styles.slide1} key={i}>
          <Image
            source={{ uri: route.params.item[`photo_main`] }}
            style={{
              resizeMode: "cover",
              height: 400,
            }}
          />
        </View>
      );
    } else if (route.params.item[`photo_${i}`] !== null && i < 7) {
      images.push(
        <View style={styles.slide1} key={i}>
          <Image
            source={{ uri: route.params.item[`photo_${i}`] }}
            style={{
              resizeMode: "cover",
              height: 400,
            }}
          />
        </View>
      );
    } else if (i === 7) {
      images.push(
        <View style={styles.slide2} key={i}>
          <Video
            source={{
              uri: "https://www.learningcontainer.com/wp-content/uploads/2020/05/sample-mp4-file.mp4",
            }}
            style={styles.video}
            useNativeControls={true}
            resizeMode="contain"
          />
        </View>
      );
    }
  }
  function handleDownloadButtonPress() {
    Linking.openURL(wordFileUrl);
  }
  const TimeAgo = ({ timestamp }) => {
    const timeAgo = moment(timestamp).fromNow();
    return (
      <View style={{ backgroundColor: "#30CAA0" }}>
        <Text style={{ padding: 1 }}>{timeAgo}</Text>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <ScrollView alwaysBounceHorizontal={false}>
        <Pressable
          onPress={() => navigation.goBack()}
          style={{
            width: "30%",
            marginTop: windowHeight * 0.03,
            marginLeft: windowWidth * 0.04,
          }}
        >
          <View style={styles.button1}>
            <Text style={{ textAlign: "center" }}>Back To Listings</Text>
          </View>
        </Pressable>
        <View style={styles.image_body}>
          <Slick style={styles.wrapper} showsButtons={true}>
            {/* <View style={styles.slide1}>
              <Image
                source={{ uri: "https://picsum.photos/700" }}
                style={{
                  resizeMode: "cover",
                  height: 400,
                }}
              />
            </View> */}
            {images}
          </Slick>
        </View>
        <View style={styles.text_body}>
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <MaterialCommunityIcons name="cash" size={24} color="#30CAA0" />
              <Text style={styles.text_b}>Asking Price: </Text>
            </View>

            <Text style={styles.text_b}>${route.params.item.price}</Text>
          </View>
          <View
            style={{
              marginVertical: windowHeight * 0.01,
              width: "100%",
              alignSelf: "center",
              borderBottomColor: "lightgray",
              borderBottomWidth: 1.2,
            }}
          />
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <FontAwesome5 name="bed" size={17} color="#30CAA0" />
              <Text style={styles.text_b}>Bedrooms: </Text>
            </View>

            <Text style={styles.text_b}>{route.params.item.bedrooms}</Text>
          </View>
          <View
            style={{
              marginVertical: windowHeight * 0.01,
              width: "100%",
              alignSelf: "center",
              borderBottomColor: "lightgray",
              borderBottomWidth: 1.2,
            }}
          />
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <FontAwesome5 name="bath" size={17} color="#30CAA0" />
              <Text style={styles.text_b}>Bathrooms: </Text>
            </View>

            <Text style={styles.text_b}>{route.params.item.bathrooms}</Text>
          </View>
          <View
            style={{
              marginVertical: windowHeight * 0.01,
              width: "100%",
              alignSelf: "center",
              borderBottomColor: "lightgray",
              borderBottomWidth: 1.2,
            }}
          />
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <FontAwesome5 name="car" size={17} color="#30CAA0" />
              <Text style={styles.text_b}>Garage: </Text>
            </View>

            <Text style={styles.text_b}>{route.params.item.garage}</Text>
          </View>
          <View
            style={{
              marginVertical: windowHeight * 0.01,
              width: "100%",
              alignSelf: "center",
              borderBottomColor: "lightgray",
              borderBottomWidth: 1.2,
            }}
          />
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <Text style={styles.text_b}>Near by food place: </Text>

            <Text style={styles.text_b}>
              {route.params.item.WhichFoodPlace}
            </Text>
          </View>
          <View
            style={{
              marginVertical: windowHeight * 0.01,
              width: "100%",
              alignSelf: "center",
              borderBottomColor: "lightgray",
              borderBottomWidth: 1.2,
            }}
          />
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <FontAwesome5 name="windows" size={17} color="#30CAA0" />
              <Text style={styles.text_b}>Square Feet: </Text>
            </View>

            <Text style={styles.text_b}>{route.params.item.sqft}</Text>
          </View>
          <View
            style={{
              marginVertical: windowHeight * 0.01,
              width: "100%",
              alignSelf: "center",
              borderBottomColor: "lightgray",
              borderBottomWidth: 1.2,
            }}
          />
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <FontAwesome name="square" size={17} color="#30CAA0" />
              <Text style={styles.text_b}>Lot Size: </Text>
            </View>

            <Text style={styles.text_b}>{route.params.item.lot_size}</Text>
          </View>
          <View
            style={{
              marginVertical: windowHeight * 0.01,
              width: "100%",
              alignSelf: "center",
              borderBottomColor: "lightgray",
              borderBottomWidth: 1.2,
            }}
          />
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Entypo name="calendar" size={17} color="#30CAA0" />
              <Text style={styles.text_b}>Listing Date: </Text>
            </View>

            <Text style={styles.text_b}>{route.params.item.list_date}</Text>
          </View>
          <View
            style={{
              marginVertical: windowHeight * 0.01,
              width: "100%",
              alignSelf: "center",
              borderBottomColor: "lightgray",
              borderBottomWidth: 1.2,
            }}
          />
          <View
            style={{ flexDirection: "row", justifyContent: "space-between" }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <FontAwesome5 name="bed" size={17} color="#30CAA0" />
              <Text style={styles.text_b}>Realtor: </Text>
            </View>

            <Text style={styles.text_b}>{route.params.item.realtor.name}</Text>
          </View>
        </View>
        <Text style={{ padding: 20 }}>{route.params.item.description}</Text>
        <View
          style={{
            borderWidth: 1,
            borderColor: "lightgray",
            height: 500,
            width: "90%",
            alignSelf: "center",
          }}
        >
          <Image
            source={{ uri: `${route.params.item.realtor.photo}` }}
            style={{
              resizeMode: "cover",
              height: 400,
            }}
          />
          <View style={{ paddingHorizontal: 20, paddingVertical: 20 }}>
            <Text style={{ fontSize: 20 }}>Property Realtor:</Text>
            <Text style={{ fontSize: 20, color: "#30CAA0" }}>
              {route.params.item.realtor.name}
            </Text>
          </View>
        </View>
        <Pressable
          style={{
            width: "90%",
            alignSelf: "center",
            marginTop: windowHeight * 0.02,
          }}
          onPress={() => openModal(setModal1Visible)}
        >
          <View style={styles.button}>
            <Text
              style={{
                color: "white",
                alignSelf: "center",
                fontSize: 17,
              }}
            >
              Make An Inquiry
            </Text>
          </View>
        </Pressable>
        <View style={styles.centeredView}>
          {modal1Visible && (
            <MakeInquiry
              isVisible={modal1Visible}
              closeModal={() => closeModal(setModal1Visible)}
              id={route.params.item.id}
              listing={route.params.item.title}
            />
          )}
        </View>
        <Pressable
          style={{
            width: "90%",
            alignSelf: "center",
            marginTop: windowHeight * 0.02,
          }}
          onPress={() => openModal(setModal2Visible)}
        >
          <View style={styles.button}>
            <Text
              style={{
                color: "white",
                alignSelf: "center",
                fontSize: 17,
              }}
            >
              Help In Transportation
            </Text>
          </View>
        </Pressable>
        <View style={styles.centeredView}>
          {modal2Visible && (
            <Transportation
              isVisible={modal2Visible}
              closeModal={() => closeModal(setModal2Visible)}
              id={route.params.item.id}
              listing={route.params.item.title}
            />
          )}
        </View>
        <Pressable
          style={{
            width: "90%",
            alignSelf: "center",
            marginTop: windowHeight * 0.02,
          }}
          onPress={() => openModal(setModal3Visible)}
        >
          <View style={styles.button}>
            <Text
              style={{
                color: "white",
                alignSelf: "center",
                fontSize: 17,
              }}
            >
              Book the house
            </Text>
          </View>
        </Pressable>
        <View style={styles.centeredView}>
          {modal3Visible && (
            <BookProperty
              isVisible={modal3Visible}
              closeModal={() => closeModal(setModal3Visible)}
              id={route.params.item.id}
              listing={route.params.item.title}
            />
          )}
        </View>
        <Pressable
          style={{
            width: "90%",
            alignSelf: "center",
            marginTop: windowHeight * 0.02,
            marginBottom: windowHeight * 0.05,
          }}
          onPress={handleDownloadButtonPress}
        >
          <View style={styles.button}>
            <Text
              style={{
                color: "white",
                alignSelf: "center",
                fontSize: 17,
              }}
            >
              Download the aggrement
            </Text>
          </View>
        </Pressable>

        <View style={{ paddingHorizontal: 20, paddingBottom: 10 }}>
          <Text style={{ fontSize: 20, fontWeight: "bold" }}>Reviews</Text>

          <View
            style={{
              marginVertical: windowHeight * 0.01,
              width: "100%",
              alignSelf: "center",
              borderBottomColor: "lightgray",
              borderBottomWidth: 1.2,
            }}
          />

          {authCtx.isAuthenticated ? (
            <View>
              <Text style={{ fontSize: 20 }}>Post a comment</Text>
              <TextInput
                style={styles.input}
                onChangeText={SetComment}
                value={comment}
                placeholder="Enter Comment"
                autoCapitalize="none"
              />
              <Pressable
                style={{
                  width: "40%",
                  marginBottom: windowHeight * 0.02,
                  marginTop: windowHeight * 0.02,
                }}
                onPress={() => {
                  if (comment.length !== 0) {
                    submit();
                    fetchData();
                  } else {
                    alert("Comment cant be null");
                  }
                }}
              >
                <View style={styles.button}>
                  <Text
                    style={{
                      color: "white",
                      alignSelf: "center",
                      fontSize: 17,
                    }}
                  >
                    Submit
                  </Text>
                </View>
              </Pressable>
            </View>
          ) : null}
          {timeout ? (
            <LoadingOverlay />
          ) : !isdata ? (
            <Text>No Comments Available</Text>
          ) : (
            <>
              {data.map((item, index) =>
                item.post === route.params.item.id ? (
                  <View key={index}>
                    <View style={{ flexDirection: "row" }}>
                      <Text
                        style={{
                          fontWeight: "bold",
                          fontSize: 15,
                          marginRight: 4,
                        }}
                      >
                        Anonymous
                      </Text>
                      <TimeAgo timestamp={item.timestamp} />
                    </View>
                    <Text style={{ fontSize: 15 }}>{item.comment}</Text>
                  </View>
                ) : null
              )}
            </>
          )}
        </View>
      </ScrollView>
    </View>
  );
};

export default MoreInfo;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  button1: {
    padding: "5%",
    borderRadius: Platform.OS === "ios" ? "6%" : 6,
    backgroundColor: "lightgray",
  },
  wrapper: {},
  slide1: {
    flex: 1,
  },
  slide2: {
    flex: 1,
  },
  slide3: {
    flex: 1,
  },
  text: {
    color: "#fff",
    fontSize: 30,
    fontWeight: "bold",
  },
  image_body: {
    height: 400,
    width: "100%",
    marginVertical: windowHeight * 0.04,
  },
  text_body: {
    padding: 20,
    height: 350,
  },
  text_b: {
    fontSize: 15,
    paddingLeft: 5,
    color: "#30CAA0",
  },
  button: {
    padding: "3%",
    borderRadius: Platform.OS === "ios" ? "6%" : 6,
    backgroundColor: "#10284E",
  },
  centeredView: {
    // marginTop: '50%',
    flex: 1,
    backgroundColor: "#000000aa",
    justifyContent: "center",
    alignItems: "center",
  },
  input: {
    height: 40,
    marginTop: windowHeight * 0.02,
    borderWidth: 1,
    borderColor: "lightgray",
    borderRadius: 4,
    padding: 7,
  },
  button2: {
    padding: "3%",
    borderRadius: Platform.OS === "ios" ? "6%" : 6,
    backgroundColor: "#20C997",
  },
  video: {
    width: "100%",
    height: "100%",
  },
  b1: {
    height: 400,
    width: 400,
    backgroundColor: "red",
  },
});
