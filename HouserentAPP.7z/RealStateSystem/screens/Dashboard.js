import { StyleSheet, Text, View } from "react-native";
import React from "react";
import { Table, TableWrapper, Row, Cell } from "react-native-table-component";

const Dashboard = () => {
  const tableHead = ["#", "Property", ""];
  return (
    <View style={styles.container}>
      <View style={{ padding: 30 }}>
        <Text style={{ fontSize: 27, fontWeight: "bold" }}>Welcome</Text>
        <Text style={{ fontSize: 20 }}>
          Here are the property Listings that you have inquired about
        </Text>
        <Table borderStyle={{ borderColor: "transparent" }}>
          <Row data={tableHead} style={styles.head} textStyle={styles.text} />
          {}
        </Table>
      </View>
    </View>
  );
};

export default Dashboard;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  head: { height: 40, backgroundColor: "#808B97" },
  text: { margin: 6 },
  row: { flexDirection: "row", backgroundColor: "#FFF1C1" },
  btn: { width: 58, height: 18, backgroundColor: "#78B7BB", borderRadius: 2 },
  btnText: { textAlign: "center", color: "#fff" },
});
