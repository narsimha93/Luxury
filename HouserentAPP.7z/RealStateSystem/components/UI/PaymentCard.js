import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  Pressable,
  Modal,
  TextInput,
  Alert,
} from "react-native";
import React, { useState } from "react";
const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;
import { Feather } from "@expo/vector-icons";

const PaymentCard = ({ id, amount }) => {
  const [cardholderName, setCardholderName] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [expirationDate, setExpirationDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const openModal = (setModalVisible) => {
    setModalVisible(true);
  };

  const closeModal = (setModalVisible) => {
    setModalVisible(false);
  };

  function submitHandler(credentials) {
    let { cardholderName, cardNumber, expirationDate, cvv } = credentials;

    cardholderName = cardholderName.trim();
    cardNumber = cardNumber.trim();
    expirationDate = expirationDate.trim();
    cvv = cvv.trim();

    const cardholderIsValid = cardholderName.length > 1;
    const numberIsValid = cardNumber.length === 16;
    const DateIsValid = expirationDate.length === 4;
    const cvvIsValid = cvv.length === 3;

    if (!cardholderIsValid || !numberIsValid || !DateIsValid || !cvvIsValid) {
      Alert.alert("Invalid input", "Invalid Card Details");
    } else {
      //Call your API function here
      Alert.alert("Payment Successfull");
    }
  }
  return (
    <View style={styles.card}>
      <Text style={{ fontSize: 20, color: "green" }}>Your House is Booked</Text>
      <View
        style={{
          marginVertical: windowHeight * 0.01,
          width: "100%",
          alignSelf: "center",
          borderBottomColor: "lightgray",
          borderBottomWidth: 1.2,
        }}
      />
      <Text style={{ fontSize: 20 }}>
        Your House has been Booked{"\n"}House id: {id}
      </Text>
      <Text style={{ fontSize: 20 }}>Your Payment Amount is : {amount}</Text>
      <Pressable
        style={{
          width: "80%",
          alignSelf: "center",
          marginTop: 10,
          paddingBottom: 20,
        }}
        onPress={() => openModal(setModalVisible)}
      >
        <View
          style={{
            backgroundColor: "#E94646",
            alignItems: "center",
            padding: 10,
            borderRadius: Platform.OS === "ios" ? "6%" : 6,
          }}
        >
          <Text style={{ color: "white", fontSize: 20 }}>Make Payment</Text>
        </View>
      </Pressable>
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={closeModal}
        style={{ flex: 1 }}
      >
        <View style={styles.centeredView}>
          <View
            style={[
              styles.modalView,
              {
                position: "absolute",
                alignSelf: "center",
              },
            ]}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                paddingTop: 20,
                paddingHorizontal: 15,
              }}
            >
              <Text style={{ fontSize: 22 }}>Make Payment</Text>
              <Pressable
                onPress={() => {
                  closeModal(setModalVisible);
                }}
              >
                <Feather name="x" size={24} color="gray" />
              </Pressable>
            </View>
            <View
              style={{
                marginVertical: windowHeight * 0.01,
                width: "100%",
                alignSelf: "center",
                borderBottomColor: "lightgray",
                borderBottomWidth: 1.2,
              }}
            />
            <View>
              <Text style={{ fontSize: 20, padding: 20 }}>
                Amount: {amount}
              </Text>
            </View>
            <View style={styles.container1}>
              <View style={styles.cardHeader}>
                <Text style={styles.cardTitle}>My Payment Card</Text>
                <Text style={styles.cardType}>Visa</Text>
              </View>
              <View style={styles.cardNumberContainer}>
                <TextInput
                  style={styles.cardNumberInput}
                  placeholder="Card Number"
                  keyboardType="numeric"
                  maxLength={16}
                  value={cardNumber}
                  onChangeText={setCardNumber}
                  placeholderTextColor="gray"
                />
              </View>
              <View style={styles.cardInputContainer}>
                <TextInput
                  style={styles.cardInput}
                  placeholder="Cardholder Name"
                  value={cardholderName}
                  onChangeText={setCardholderName}
                  placeholderTextColor="gray"
                />
                <TextInput
                  style={styles.cardInput}
                  placeholder="Expiration Date"
                  keyboardType="numeric"
                  maxLength={4}
                  value={expirationDate}
                  onChangeText={setExpirationDate}
                  placeholderTextColor="gray"
                />
                <TextInput
                  style={styles.cardInput}
                  placeholder="CVV"
                  keyboardType="numeric"
                  maxLength={3}
                  value={cvv}
                  onChangeText={setCvv}
                  placeholderTextColor="gray"
                />
              </View>
            </View>
            <Pressable
              onPress={() =>
                submitHandler({
                  cardholderName: cardholderName,
                  cardNumber: cardNumber,
                  expirationDate: expirationDate,
                  cvv: cvv,
                })
              }
              style={{ width: "50%", alignSelf: "center", marginTop: "10%" }}
            >
              <View
                style={{
                  backgroundColor: "#10284E",
                  padding: 10,
                  borderRadius: Platform.OS === "ios" ? "6%" : 6,
                  alignItems: "center",
                }}
              >
                <Text style={{ fontSize: 20, color: "white" }}>Pay Now</Text>
              </View>
            </Pressable>

            <Text
              style={{ textAlign: "center", fontSize: 18, paddingVertical: 30 }}
            >
              Secured By RazorPay
            </Text>
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default PaymentCard;

const styles = StyleSheet.create({
  card: {
    width: "100%",
    borderWidth: 1,
    borderColor: "lightgray",
    marginHorizontal: 4,
    marginVertical: 6,
    padding: 10,
  },
  centeredView: {
    // marginTop: '50%',
    flex: 1,
    backgroundColor: "#000000aa",
    justifyContent: "center",
    alignItems: "center",
  },
  modalView: {
    backgroundColor: "#3BA67B",
    width: "95%",
    height: "95%",
    // padding: 20,
    // alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 10,
  },
  container1: {
    backgroundColor: "#fff",
    padding: 20,
    borderRadius: 10,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: "bold",
  },
  cardType: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#999",
  },
  cardNumberContainer: {
    backgroundColor: "#f5f5f5",
    padding: 20,
    borderRadius: 10,
    marginBottom: 10,
  },
  cardNumberInput: {
    fontSize: 24,
    fontWeight: "bold",
    letterSpacing: 4,
  },
  cardInputContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cardInput: {
    flex: 1,
    marginRight: 10,
    paddingVertical: 10,
    paddingHorizontal: 15,
    backgroundColor: "#f5f5f5",
    borderRadius: 10,
    fontSize: 16,
  },
});
