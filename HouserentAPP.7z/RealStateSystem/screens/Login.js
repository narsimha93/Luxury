import { View, Text, StyleSheet } from "react-native";
import { useState, useContext } from "react";
import { Alert } from "react-native";
import LoginForm from "../components/Forms/LoginForm";
import LoadingOverlay from "../components/UI/LoadingOverlay";
import { AuthContext } from "../store/auth-context";
import jwt_decode from "jwt-decode";

const Login = () => {
  const authCtx = useContext(AuthContext);
  const [isAuthentication, setAuthentication] = useState(false);
  async function loginHandler({ username, password }) {
    setAuthentication(true);

    // const token = await loginUser(email, password);
    //

    try {
      const userdata = { username: username, password: password };
      const response = await fetch(
        "https://house-rent.herokuapp.com/accounts/loginapi/",
        {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(userdata),
        }
      );
      data = await response.json();
      console.log(response);
      if (response.status === 401) {
        setAuthentication(false);
        alert(data.detail);
      } else {
        var decoded = jwt_decode(data.access);

        authCtx.authenticate(data.access);
      }
    } catch (error) {
      console.log(JSON.stringify(error));
    }
  }

  if (isAuthentication) {
    return <LoadingOverlay message="Loggin you in ..." />;
  }

  return <LoginForm onAuthenticate={loginHandler} />;
};

export default Login;

const styles = StyleSheet.create({});
