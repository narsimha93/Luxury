import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
  Pressable,
  Alert,
} from "react-native";
import React, { useState } from "react";
import { Entypo } from "@expo/vector-icons";
import { ScrollView } from "react-native-gesture-handler";
const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;

const RegisterationForm = ({ onAuthenticate }) => {
  const [credentialsInvalid, setCredentialsInvalid] = useState({
    firstname: false,
    lastname: false,
    email: false,
    password: false,
    confirmpassword: false,
    username: false,
  });

  const [enteredEmail, setEnteredEmail] = useState("");
  const [enteredFirstname, setEnteredFirstname] = useState("");
  const [enteredLastname, setEnteredLastname] = useState("");
  const [enteredPassword, setEnteredPassword] = useState("");
  const [enteredConfirmPassword, setEnteredConfirmPassword] = useState("");
  const [enteredUsername, setEnteredUsername] = useState("");

  function submitHandler(credentials) {
    let { firstname, lastname, email, password, confirmpassword, username } =
      credentials;

    firstname = firstname.trim();
    lastname = lastname.trim();
    email = email.trim();
    password = password.trim();
    confirmpassword = confirmpassword.trim();
    username = username.trim();

    let reg_email = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;

    const firstnameIsValid = firstname.length > 1;
    const lastnameIsValid = lastname.length > 1;
    const emailIsValid = reg_email.test(email) || email.length > 1;
    const passwordIsValid = password.length > 2;
    const passwordsAreEqual = confirmpassword === password;
    const usernameIsValid = username.length > 1;

    if (
      !emailIsValid ||
      !passwordIsValid ||
      !firstnameIsValid ||
      !lastnameIsValid ||
      !passwordsAreEqual ||
      !usernameIsValid
    ) {
      Alert.alert("Invalid input", "Please check your entered credentials.");
      setCredentialsInvalid({
        firstname: !firstnameIsValid,
        lastname: !lastnameIsValid,
        email: !emailIsValid,
        password: !passwordIsValid,
        confirmpassword: !passwordIsValid || !passwordsAreEqual,
        username: !usernameIsValid,
      });
      return;
    }
    // onAuthenticate({ firstname, lastname, email, password, cnic });
    onAuthenticate({
      username,
      email,
      firstname,
      lastname,
      password,
      confirmpassword,
    });
    setEnteredEmail("");
    setEnteredFirstname("");
    setEnteredPassword("");
    setEnteredLastname("");
    setEnteredUsername("");
    setEnteredConfirmPassword("");
  }

  function updateInputValueHandler(inputType, enteredValue) {
    switch (inputType) {
      case "firstname":
        setEnteredFirstname(enteredValue);
        break;
      case "lastname":
        setEnteredLastname(enteredValue);
        break;
      case "email":
        setEnteredEmail(enteredValue);
        break;
      case "password":
        setEnteredPassword(enteredValue);
        break;
      case "confirmpassword":
        setEnteredConfirmPassword(enteredValue);
        break;
      case "username":
        setEnteredUsername(enteredValue);
        break;
    }
  }

  return (
    <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
      <View style={styles.container}>
        <View style={styles.body}>
          <View
            style={{
              backgroundColor: "red",
              height: windowHeight * 0.07,
              flexDirection: "row",
              alignItems: "center",
              paddingLeft: windowWidth * 0.05,
            }}
          >
            <Entypo name="login" size={24} color="white" />
            <Text
              style={{
                fontWeight: "bold",
                fontSize: 20,
                color: "white",
                marginLeft: windowWidth * 0.01,
              }}
            >
              REGISTER
            </Text>
          </View>
          <ScrollView>
            <View style={{ paddingHorizontal: 30, paddingTop: 20 }}>
              <View>
                <Text style={{ fontWeight: "bold", fontSize: 16 }}>
                  Username :{" "}
                </Text>
                <TextInput
                  style={styles.input}
                  onChangeText={updateInputValueHandler.bind(this, "username")}
                  value={enteredUsername}
                  placeholder="Enter Username"
                  autoCapitalize="none"
                />
                {credentialsInvalid.username ? (
                  <Text style={{ color: "red", padding: 5 }}>
                    Username Length Should be greater than 1
                  </Text>
                ) : null}
              </View>
            </View>
            <View style={{ paddingHorizontal: 30, paddingTop: 20 }}>
              <View>
                <Text style={{ fontWeight: "bold", fontSize: 16 }}>
                  First Name :{" "}
                </Text>
                <TextInput
                  style={styles.input}
                  onChangeText={updateInputValueHandler.bind(this, "firstname")}
                  value={enteredFirstname}
                  placeholder="Enter First Name"
                  autoCapitalize="none"
                />
                {credentialsInvalid.firstname ? (
                  <Text style={{ color: "red", padding: 5 }}>
                    Firstname Length Should be greater than 1
                  </Text>
                ) : null}
              </View>
            </View>
            <View style={{ paddingHorizontal: 30, paddingTop: 20 }}>
              <View>
                <Text style={{ fontWeight: "bold", fontSize: 16 }}>
                  Last Name :{" "}
                </Text>
                <TextInput
                  style={styles.input}
                  onChangeText={updateInputValueHandler.bind(this, "lastname")}
                  value={enteredLastname}
                  placeholder="Enter Last Name"
                  autoCapitalize="none"
                />
                {credentialsInvalid.lastname ? (
                  <Text style={{ color: "red", padding: 5 }}>
                    LastName Length Should be greater than 1
                  </Text>
                ) : null}
              </View>
            </View>
            <View style={{ paddingHorizontal: 30, paddingTop: 20 }}>
              <View>
                <Text style={{ fontWeight: "bold", fontSize: 16 }}>
                  Email :{" "}
                </Text>
                <TextInput
                  style={styles.input}
                  onChangeText={updateInputValueHandler.bind(this, "email")}
                  value={enteredEmail}
                  placeholder="Enter Email"
                  autoCapitalize="none"
                />
                {credentialsInvalid.email ? (
                  <Text style={{ color: "red", padding: 5 }}>
                    Email Length Should be greater than 1
                  </Text>
                ) : null}
              </View>
            </View>
            <View style={{ paddingHorizontal: 30, paddingTop: 20 }}>
              <View>
                <Text style={{ fontWeight: "bold", fontSize: 16 }}>
                  Password :{" "}
                </Text>
                <TextInput
                  style={styles.input}
                  onChangeText={updateInputValueHandler.bind(this, "password")}
                  value={enteredPassword}
                  placeholder="Enter Password"
                  autoCapitalize="none"
                  secureTextEntry={true}
                />
                {credentialsInvalid.password ? (
                  <Text style={{ color: "red", padding: 5 }}>
                    password Length Should be greater than 1
                  </Text>
                ) : null}
              </View>
            </View>
            <View style={{ paddingHorizontal: 30, paddingVertical: 20 }}>
              <View>
                <Text style={{ fontWeight: "bold", fontSize: 16 }}>
                  Confirm Password :{" "}
                </Text>
                <TextInput
                  style={styles.input}
                  onChangeText={updateInputValueHandler.bind(
                    this,
                    "confirmpassword"
                  )}
                  value={enteredConfirmPassword}
                  placeholder="Enter Password Again"
                  autoCapitalize="none"
                  secureTextEntry={true}
                />
                {credentialsInvalid.confirmpassword ? (
                  <Text style={{ color: "red", padding: 5 }}>
                    Confirm Password Length Should be greater than 1
                  </Text>
                ) : null}
              </View>
            </View>
            <Pressable
              onPress={() => {
                submitHandler({
                  firstname: enteredFirstname,
                  lastname: enteredLastname,
                  email: enteredEmail,
                  username: enteredUsername,
                  password: enteredPassword,
                  confirmpassword: enteredConfirmPassword,
                });
              }}
              style={{
                width: "90%",
                alignSelf: "center",
                marginTop: windowHeight * 0.02,
                marginBottom: windowHeight * 0.02,
              }}
            >
              <View style={styles.button}>
                <Text
                  style={{
                    color: "white",
                    alignSelf: "center",
                    fontSize: 17,
                  }}
                >
                  REGISTER
                </Text>
              </View>
            </Pressable>
          </ScrollView>
        </View>
        <View style={styles.footer}>
          <View
            style={{
              backgroundColor: "#00008B",
              width: "100%",
              height: windowHeight * 0.07,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ color: "white" }}>
              Copyright © 2023 Luxury House
            </Text>
          </View>
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
};

export default RegisterationForm;

const styles = StyleSheet.create({
  container: { flex: 1 },
  body: {
    width: windowWidth * 0.9,
    height: windowHeight * 0.78,
    alignSelf: "center",
    marginTop: windowHeight * 0.03,
    shadowColor: "black",
    shadowOpacity: 0.1,
    shadowRadius: 3,
    shadowOffset: {
      height: 0,
      width: 0,
    },
    elevation: 1,
    backgroundColor: "white",
  },
  footer: {
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",
  },
  input: {
    height: 40,
    marginTop: windowHeight * 0.02,
    borderWidth: 1,
    borderColor: "lightgray",
    borderRadius: 4,
    padding: 7,
  },
  button: {
    padding: "3%",
    borderRadius: Platform.OS === "ios" ? "6%" : 6,
    backgroundColor: "#20C997",
  },
});
