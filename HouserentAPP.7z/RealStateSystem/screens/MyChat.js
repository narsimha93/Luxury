import { StyleSheet, View, Text } from "react-native";
import React, { useEffect, useState } from "react";
import { GiftedChat } from "react-native-gifted-chat";
import axios from "axios";
const MyChat = () => {
  const [messages, setMessages] = useState([]);
  const CHAT_GPT_API_KEY =
    "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";
  const handleSend = async (newMessages = []) => {
    try {
      const userMessage = newMessages[0];
      setMessages((previousMessages) =>
        GiftedChat.append(previousMessages, userMessage)
      );
      const messageText = userMessage.text.toLowerCase();
      const keywords = ["help", "property", "cheap", "best"];
      if (!keywords.some((keyword) => messageText.includes(keyword))) {
        const botMessage = {
          _id: new Date().getTime() + 1,
          text: "I am your property Bot ,ask me anything related to Property",
          createdAt: new Date(),
          user: {
            _id: 2,
            name: "Naman Garg",
          },
        };
        setMessages((previousMessages) =>
          GiftedChat.append(previousMessages, botMessage)
        );
        return;
      }
      const response = await axios.post(
        "https://api.openai.com/v1/engines/text-davinci-003/completions",
        {
          prompt: ` Help me with this ${messageText}`,
          max_tokens: 1200,
          temperature: 0.2,
          n: 1,
        },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${CHAT_GPT_API_KEY}`,
          },
        }
      );
      console.log(response.data);
      const property = response.data.choices[0].text.trim();
      const botMessage = {
        _id: new Date().getTime() + 1,
        text: property,
        createdAt: new Date(),
        user: {
          _id: 2,
          name: "Naman Garg",
        },
      };
      setMessages((previousMessages) =>
        GiftedChat.append(previousMessages, botMessage)
      );
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <View style={styles.container}>
      <GiftedChat
        messages={messages}
        onSend={(newMessages) => handleSend(newMessages)}
        user={{ _id: 1 }}
      />
    </View>
  );
};

export default MyChat;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  webview: {
    flex: 1,
  },
});
