import {
  StyleSheet,
  Text,
  View,
  Modal,
  Dimensions,
  Pressable,
  TextInput,
  Keyboard,
  TouchableWithoutFeedback,
  KeyboardAvoidingView,
  ScrollView,
  Alert,
} from "react-native";
import React, { useState, useContext } from "react";
const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;
import { Feather } from "@expo/vector-icons";
import { AuthContext } from "../../store/auth-context";
const Transportation = ({ isVisible, closeModal, id, listing }) => {
  const authCtx = useContext(AuthContext);
  const [property, setProperty] = useState(listing);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [pincode, setPincode] = useState("");
  const [boxes, setBoxes] = useState("");
  const [truck_req, setTruck] = useState("");

  const [credentialsInvalid, setCredentialsInvalid] = useState({
    property: false,
    name: false,
    email: false,
    phone: false,
    address: false,
    pincode: false,
    boxes: false,
    truck_req: false,
  });
  const submit = async () => {
    const token = authCtx.token;
    var decoded = jwt_decode(token);
    const formData = {
      listing: listing,
      listing_id: id,
      name: name,
      email: email,
      owner_phone_number: parseInt(phone),
      onwer_address: address,
      owner_pincode: pincode,
      no_of_boxes: parseInt(boxes),
      truck_requirement: parseInt(truck_req),
      user_id: decoded.user_id,
    };

    const response = await fetch(
      "https://house-rent.herokuapp.com/contacts/transportapi/",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      }
    );
    const data = await response.json();
    if (response.status === 401) {
      console.log(data);
      alert("Could not Submit");
    } else {
      alert("Booking Sent");
      setAddress("");
      setBoxes("");
      setEmail("");
      setName("");
      setPhone("");
      setPincode("");
      setTruck("");
    }
  };
  function submitHandler(credentials) {
    let { property, name, email, phone, address, pincode, boxes, truck_req } =
      credentials;

    property = property.trim();
    name = name.trim();
    email = email.trim();
    phone = phone.trim();
    address = address.trim();
    pincode = pincode.trim();
    boxes = boxes.trim();
    truck_req = truck_req.trim();

    let reg_email = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
    const propertyIsValid = property.length >= 1;
    const nameIsValid = name.length >= 1;
    const emailIsValid = reg_email.test(email);
    const phoneIsValid = phone.length === 11;
    const addressIsValid = address.length >= 1;
    const pincodeIsValid = pincode.length >= 1;
    const boxesIsValid = boxes.length >= 1;
    const truck_reqIsValid = truck_req.length >= 1;

    if (
      !emailIsValid ||
      !propertyIsValid ||
      !nameIsValid ||
      !phoneIsValid ||
      !addressIsValid ||
      !pincodeIsValid ||
      !boxesIsValid ||
      !truck_reqIsValid
    ) {
      Alert.alert("Invalid input", "Please check your entered credentials.");
      setCredentialsInvalid({
        property: !propertyIsValid,
        name: !nameIsValid,
        email: !emailIsValid,
        phone: !phoneIsValid,
        address: !addressIsValid,
        pincode: !pincodeIsValid,
        boxes: !boxesIsValid,
        truck_req: !truck_reqIsValid,
      });
    } else {
      setCredentialsInvalid({
        property: !propertyIsValid,
        name: !nameIsValid,
        email: !emailIsValid,
        phone: !phoneIsValid,
        address: !addressIsValid,
        pincode: !pincodeIsValid,
        boxes: !boxesIsValid,
        truck_req: !truck_reqIsValid,
      });
      //Call your API function here
      submit();
    }
  }
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={closeModal}
      style={{ flex: 1 }}
    >
      <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
        <View style={styles.centeredView}>
          <View
            style={[
              styles.modalView,
              {
                position: "absolute",
                alignSelf: "center",
              },
            ]}
          >
            <KeyboardAvoidingView
              behavior={Platform.OS === "ios" ? "padding" : "height"}
              style={{ flex: 1 }}
              keyboardVerticalOffset={30}
            >
              <ScrollView>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    paddingTop: 20,
                    paddingHorizontal: 15,
                  }}
                >
                  <Text style={{ fontSize: 22 }}>
                    Get a truck at the door step
                  </Text>
                  <Pressable onPress={closeModal}>
                    <Feather name="x" size={24} color="gray" />
                  </Pressable>
                </View>
                <View
                  style={{
                    marginVertical: windowHeight * 0.02,
                    width: "100%",
                    alignSelf: "center",
                    borderBottomColor: "lightgray",
                    borderBottomWidth: 1.2,
                  }}
                />
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Property: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.property && { borderColor: "red" },
                    ]}
                    onChangeText={setProperty}
                    value={property}
                    autoCapitalize="none"
                  />
                  {credentialsInvalid.property ? (
                    <Text style={{ color: "red" }}>
                      This Field Cannot be empty
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Name: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.name && { borderColor: "red" },
                    ]}
                    onChangeText={setName}
                    value={name}
                    autoCapitalize="none"
                  />
                  {credentialsInvalid.name ? (
                    <Text style={{ color: "red" }}>
                      Name length should be greater than 1
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Email: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.email && { borderColor: "red" },
                    ]}
                    onChangeText={setEmail}
                    value={email}
                    autoCapitalize="none"
                  />
                  {credentialsInvalid.email ? (
                    <Text style={{ color: "red" }}>
                      Enter a valid Email format
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Owner Phone number: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.phone && { borderColor: "red" },
                    ]}
                    onChangeText={setPhone}
                    value={phone}
                    autoCapitalize="none"
                    keyboardType={"numeric"}
                    maxLength={11}
                  />
                  {credentialsInvalid.phone ? (
                    <Text style={{ color: "red" }}>
                      Enter a Valid Phone number (11 Digits)
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Owner Address: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.address && { borderColor: "red" },
                      { height: 60 },
                    ]}
                    onChangeText={setAddress}
                    value={address}
                    autoCapitalize="none"
                    multiline={true}
                    numberOfLines={2}
                  />
                  {credentialsInvalid.address ? (
                    <Text style={{ color: "red" }}>
                      Address length should be greater than 1
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Owner Pincode: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.pincode && { borderColor: "red" },
                    ]}
                    onChangeText={setPincode}
                    value={pincode}
                    autoCapitalize="none"
                    keyboardType={"numeric"}
                  />
                  {credentialsInvalid.pincode ? (
                    <Text style={{ color: "red" }}>
                      This Field can't be empty
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>No. of boxes: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.boxes && { borderColor: "red" },
                    ]}
                    onChangeText={setBoxes}
                    value={boxes}
                    autoCapitalize="none"
                    keyboardType={"numeric"}
                  />
                  {credentialsInvalid.boxes ? (
                    <Text style={{ color: "red" }}>
                      This Field can't be empty
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Truck_requirements: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.truck_req && { borderColor: "red" },
                      { height: 60 },
                    ]}
                    onChangeText={setTruck}
                    value={truck_req}
                    autoCapitalize="none"
                    multiline={true}
                    numberOfLines={2}
                    keyboardType={"numeric"}
                  />
                  {credentialsInvalid.truck_req ? (
                    <Text style={{ color: "red" }}>
                      This Field can't be empty
                    </Text>
                  ) : null}
                </View>
                <Pressable
                  style={{
                    width: "90%",
                    alignSelf: "center",
                    marginTop: windowHeight * 0.02,
                    marginBottom: windowHeight * 0.05,
                  }}
                  onPress={() =>
                    submitHandler({
                      property: property,
                      name: name,
                      email: email,
                      phone: phone,
                      address: address,
                      pincode: pincode,
                      boxes: boxes,
                      truck_req: truck_req,
                    })
                  }
                >
                  <View style={styles.button}>
                    <Text
                      style={{
                        color: "white",
                        alignSelf: "center",
                        fontSize: 17,
                      }}
                    >
                      Send
                    </Text>
                  </View>
                </Pressable>
              </ScrollView>
            </KeyboardAvoidingView>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

export default Transportation;

const styles = StyleSheet.create({
  centeredView: {
    // marginTop: '50%',
    flex: 1,
    backgroundColor: "#000000aa",
    justifyContent: "center",
    alignItems: "center",
  },
  modalView: {
    backgroundColor: "white",
    width: "95%",
    height: "95%",
    // padding: 20,
    // alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 10,
  },
  input: {
    height: 40,
    marginTop: windowHeight * 0.01,
    borderWidth: 1,
    borderColor: "lightgray",
    borderRadius: 4,
    padding: 7,
    fontSize: 17,
  },
  button: {
    padding: "3%",
    borderRadius: Platform.OS === "ios" ? "6%" : 6,
    backgroundColor: "#30CAA0",
  },
});
