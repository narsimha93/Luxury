import { StyleSheet, Text, View } from "react-native";
import React from "react";

const Aboutus = () => {
  return (
    <View>
      <Text>Aboutus</Text>
    </View>
  );
};

export default Aboutus;

const styles = StyleSheet.create({});
