import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  VirtualizedList,
} from "react-native";
import React, { useState, useEffect, useContext } from "react";
import PaymentCard from "../components/UI/PaymentCard";
const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;
import axios from "axios";
import { AuthContext } from "../store/auth-context";
import LoadingOverlay from "../components/UI/LoadingOverlay";
const MyBookings = () => {
  const authCtx = useContext(AuthContext);
  const [data, setData] = useState(null);
  const [timeout, settime] = useState(true);
  const [isdata, setisdata] = useState(true);

  const fetchData = async () => {
    let isUnmounted = false;
    settime(true);
    const token = authCtx.token;
    await axios
      .get("https://house-rent.herokuapp.com/bookings/bookingapi/", {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      })
      .then(function (response) {
        if (!isUnmounted) {
          console.log(response.data);
          setData(response.data);
          setTimeout(() => {
            settime(false);
          }, 2500);
        }
      })
      .catch(function (error) {
        console.log(error);
      });
    return () => {
      isUnmounted = true;
    };
  };
  useEffect(() => {
    fetchData();
  }, []);
  useEffect(() => {
    if (data == null || data == undefined || data.length == 0) {
      setisdata(false);
    } else {
      setisdata(true);
    }
  }, [isdata, data]);

  const renderItem = ({ item }) => {
    return (
      <View style={styles.container1}>
        <PaymentCard id={item.id} amount={1600} />
      </View>
    );
  };
  const getItem = (data, index) => {
    return data[index];
  };
  return (
    <View style={styles.container}>
      {timeout ? (
        <LoadingOverlay />
      ) : isdata == false ? (
        <Text>No Bookings Available</Text>
      ) : (
        <VirtualizedList
          data={data}
          initialNumToRender={5}
          renderItem={renderItem}
          //onRefresh={}
          //  refreshing={timeout}
          keyExtractor={(item) => item.id}
          getItemCount={(data) => data.length}
          getItem={getItem}
        />
      )}
    </View>
  );
};

export default MyBookings;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  container1: {
    width: windowWidth * 0.9,
    alignSelf: "center",
    marginTop: windowHeight * 0.02,
  },
});
