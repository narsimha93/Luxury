import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  TextInput,
  TouchableWithoutFeedback,
  Keyboard,
  Pressable,
  Alert,
} from "react-native";
import React, { useState } from "react";
import { Entypo } from "@expo/vector-icons";

const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;

const LoginForm = ({ onAuthenticate }) => {
  const [credentialsInvalid, setCredentialsInvalid] = useState({
    username: false,
    password: false,
  });
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  function submitHandler(credentials) {
    let { username, password } = credentials;

    username = username.trim();
    password = password.trim();

    const usernameIsValid = username.length > 1;
    const passwordIsValid = password.length > 1;

    if (!usernameIsValid || !passwordIsValid) {
      Alert.alert("Invalid input", "Please check your entered credentials.");
      setCredentialsInvalid({
        username: !usernameIsValid,
        password: !passwordIsValid,
      });
      return;
    }
    onAuthenticate({ username, password });
  }

  function updateInputValueHandler(inputType, enteredValue) {
    switch (inputType) {
      case "username":
        setUsername(enteredValue);
        break;
      case "password":
        setPassword(enteredValue);
        break;
    }
  }
  return (
    <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
      <View style={styles.container}>
        <View style={styles.body}>
          <View
            style={{
              backgroundColor: "red",
              height: windowHeight * 0.07,
              flexDirection: "row",
              alignItems: "center",
              paddingLeft: windowWidth * 0.05,
            }}
          >
            <Entypo name="login" size={24} color="white" />
            <Text
              style={{
                fontWeight: "bold",
                fontSize: 20,
                color: "white",
                marginLeft: windowWidth * 0.01,
              }}
            >
              LOGIN
            </Text>
          </View>
          <View style={{ paddingHorizontal: 30, paddingTop: 30 }}>
            <View>
              <Text style={{ fontWeight: "bold", fontSize: 16 }}>
                Username :{" "}
              </Text>
              <TextInput
                style={styles.input}
                onChangeText={updateInputValueHandler.bind(this, "username")}
                value={username}
                placeholder="Enter Username"
                autoCapitalize="none"
              />
              {credentialsInvalid.username ? (
                <Text style={{ color: "red", padding: 5 }}>
                  Username Length Should be greater than 1
                </Text>
              ) : null}
            </View>
          </View>
          <View style={{ padding: 30 }}>
            <View>
              <Text style={{ fontWeight: "bold", fontSize: 16 }}>
                Password :{" "}
              </Text>
              <TextInput
                style={styles.input}
                onChangeText={updateInputValueHandler.bind(this, "password")}
                value={password}
                placeholder="Enter Password"
                autoCapitalize="none"
                secureTextEntry={true}
              />
              {credentialsInvalid.password ? (
                <Text style={{ color: "red", padding: 5 }}>
                  passwowrd Length Should be greater than 1
                </Text>
              ) : null}
            </View>
          </View>
          <Pressable
            onPress={() => {
              submitHandler({
                username: username,
                password: password,
              });
            }}
            style={{
              width: "90%",
              alignSelf: "center",
              marginTop: windowHeight * 0.02,
            }}
          >
            <View style={styles.button}>
              <Text
                style={{
                  color: "white",
                  alignSelf: "center",
                  fontSize: 17,
                }}
              >
                LOGIN
              </Text>
            </View>
          </Pressable>
        </View>
        <View style={styles.footer}>
          <View
            style={{
              backgroundColor: "#00008B",
              width: "100%",
              height: windowHeight * 0.07,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ color: "white" }}>
              Copyright © 2023 Luxury House
            </Text>
          </View>
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
};

export default LoginForm;

const styles = StyleSheet.create({
  container: { flex: 1 },
  body: {
    width: windowWidth * 0.9,
    height: windowHeight * 0.6,
    alignSelf: "center",
    marginTop: windowHeight * 0.06,
    shadowColor: "black",
    shadowOpacity: 0.1,
    shadowRadius: 3,
    shadowOffset: {
      height: 0,
      width: 0,
    },
    elevation: 1,
    backgroundColor: "white",
  },
  footer: {
    flex: 1,
    justifyContent: "flex-end",
    alignItems: "center",
  },
  input: {
    height: 40,
    marginTop: windowHeight * 0.02,
    borderWidth: 1,
    borderColor: "lightgray",
    borderRadius: 4,
    padding: 7,
  },
  button: {
    padding: "3%",
    borderRadius: Platform.OS === "ios" ? "6%" : 6,
    backgroundColor: "#20C997",
  },
});
