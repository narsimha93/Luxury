import {
  StyleSheet,
  Text,
  View,
  Modal,
  Dimensions,
  Pressable,
  TextInput,
  Keyboard,
  TouchableWithoutFeedback,
  KeyboardAvoidingView,
  ScrollView,
  Alert,
  TouchableOpacity,
} from "react-native";
import React, { useState, useContext } from "react";
const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;
import { Feather } from "@expo/vector-icons";
import * as DocumentPicker from "expo-document-picker";
import axios from "axios";
import jwt_decode from "jwt-decode";
import { AuthContext } from "../../store/auth-context";

const BookProperty = ({ isVisible, closeModal, id, listing }) => {
  const authCtx = useContext(AuthContext);

  const [property, setProperty] = useState(listing);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [ssn, setSsn] = useState("");
  const [members, setMembers] = useState("");
  const [agreement, setAgreement] = useState(null);

  const [credentialsInvalid, setCredentialsInvalid] = useState({
    property: false,
    name: false,
    email: false,
    phone: false,
    ssn: false,
    members: false,
    agreement: false,
  });

  const edit = async () => {
    const token = authCtx.token;
    var decoded = jwt_decode(token);
    const formData = new FormData();
    formData.append("aggrement", {
      uri: agreement.uri,
      name: agreement.name,
      type: agreement.type,
    });
    formData.append("listing_id", id);
    formData.append("name", name);
    formData.append("email", email);
    formData.append("phone_number", phone);
    formData.append("social_security_number", parseInt(ssn));
    formData.append("family_members", parseInt(members));
    formData.append("user_id", decoded.user_id);

    // const formData = {
    //   listing_id: id,
    //   name: name,
    //   email: email,
    //   phone_number: phone,
    //   social_security_number: parseInt(ssn),
    //   family_members: parseInt(members),
    //   user_id: 2,
    //   aggrement: agreement.uri,
    // };
    const response = await fetch(
      "https://house-rent.herokuapp.com/bookings/bookingapi/",
      {
        method: "POST",
        headers: {
          "Content-Type": "multipart/form-data",
        },
        body: formData,
      }
    );
    const data = await response.json();
    if (response.status === 400) {
      console.log(data);
    } else {
      alert("Booking Sent");
      setProperty("");
      setEmail("");
      setMembers("");
      setAgreement(null);
      setName("");
      setPhone("");
      setSsn("");
    }
    // await axios
    //   .post(`https://house-rent.herokuapp.com/bookings/bookingapi/`, {
    //     listing_id: id,
    //     name: name,
    //     email: email,
    //     phone_number: phone,
    //     social_security_number: parseInt(ssn),
    //     family_members: parseInt(members),
    //     user_id: 2,
    //     aggrement: agreement.uri,
    //   })
    //   .then(function (response) {

    //   })
    //   .catch(function (error) {
    //     console.log(error);
    //   });
  };

  const checkPermissions = async () => {
    try {
      const result = await PermissionsAndroid.check(
        PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE
      );

      if (!result) {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
          {
            title:
              "You need to give storage permission to download and save the file",
            message: "App needs access to your camera ",
            buttonNeutral: "Ask Me Later",
            buttonNegative: "Cancel",
            buttonPositive: "OK",
          }
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          console.log("You can use the camera");
          return true;
        } else {
          Alert.alert("Error", I18n.t("PERMISSION_ACCESS_FILE"));

          console.log("Camera permission denied");
          return false;
        }
      } else {
        return true;
      }
    } catch (err) {
      console.warn(err);
      return false;
    }
  };
  async function selectFile() {
    try {
      //  const result = await checkPermissions();

      if (true) {
        const result = await DocumentPicker.getDocumentAsync({
          copyToCacheDirectory: false,
          type: "*/*",
        });

        if (result.type === "success") {
          // Printing the log realted to the file
          console.log("res : " + JSON.stringify(result));
          // Setting the state to show single file attributes

          setAgreement(result);
        }
      }
    } catch (err) {
      setAgreement(null);
      Alert(err);
      return false;
    }
  }
  function submitHandler(credentials) {
    let { property, name, email, phone, ssn, members, agreement } = credentials;

    property = property.trim();
    name = name.trim();
    email = email.trim();
    phone = phone.trim();
    ssn = ssn.trim();
    members = members.trim();

    let reg_email = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w\w+)+$/;
    const propertyIsValid = property.length >= 1;
    const nameIsValid = name.length >= 1;
    const emailIsValid = reg_email.test(email);
    const phoneIsValid = phone.length === 11;
    const ssnIsValid = ssn.length >= 1;
    const membersIsValid = members.length >= 1;
    const agreementIsValid = agreement != null;

    if (
      !emailIsValid ||
      !propertyIsValid ||
      !nameIsValid ||
      !phoneIsValid ||
      !ssnIsValid ||
      !membersIsValid ||
      !agreementIsValid
    ) {
      Alert.alert("Invalid input", "Please check your entered credentials.");
      setCredentialsInvalid({
        property: !propertyIsValid,
        name: !nameIsValid,
        email: !emailIsValid,
        phone: !phoneIsValid,
        ssn: !ssnIsValid,
        members: !membersIsValid,
        agreement: !agreementIsValid,
      });
    } else {
      setCredentialsInvalid({
        property: !propertyIsValid,
        name: !nameIsValid,
        email: !emailIsValid,
        phone: !phoneIsValid,
        ssn: !ssnIsValid,
        members: !membersIsValid,
        agreement: !agreementIsValid,
      });
      //Call your API function here
      edit();
    }
  }
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={isVisible}
      onRequestClose={closeModal}
      style={{ flex: 1 }}
    >
      <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
        <View style={styles.centeredView}>
          <View
            style={[
              styles.modalView,
              {
                position: "absolute",
                alignSelf: "center",
              },
            ]}
          >
            <KeyboardAvoidingView
              behavior={Platform.OS === "ios" ? "padding" : "height"}
              style={{ flex: 1 }}
              keyboardVerticalOffset={30}
            >
              <ScrollView>
                <View
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "space-between",
                    paddingTop: 20,
                    paddingHorizontal: 15,
                  }}
                >
                  <Text style={{ fontSize: 22 }}>Book the House</Text>
                  <Pressable onPress={closeModal}>
                    <Feather name="x" size={24} color="gray" />
                  </Pressable>
                </View>
                <View
                  style={{
                    marginVertical: windowHeight * 0.02,
                    width: "100%",
                    alignSelf: "center",
                    borderBottomColor: "lightgray",
                    borderBottomWidth: 1.2,
                  }}
                />
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Property: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.property && { borderColor: "red" },
                    ]}
                    onChangeText={setProperty}
                    value={property}
                    autoCapitalize="none"
                  />
                  {credentialsInvalid.property ? (
                    <Text style={{ color: "red" }}>
                      This Field Cannot be empty
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Name: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.name && { borderColor: "red" },
                    ]}
                    onChangeText={setName}
                    value={name}
                    autoCapitalize="none"
                  />
                  {credentialsInvalid.name ? (
                    <Text style={{ color: "red" }}>
                      This Field Cannot be empty
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Email: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.email && { borderColor: "red" },
                    ]}
                    onChangeText={setEmail}
                    value={email}
                    autoCapitalize="none"
                  />
                  {credentialsInvalid.email ? (
                    <Text style={{ color: "red" }}>
                      Please Enter a Valid Email
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Phone number: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.phone && { borderColor: "red" },
                    ]}
                    onChangeText={setPhone}
                    value={phone}
                    autoCapitalize="none"
                    keyboardType={"numeric"}
                    maxLength={11}
                  />
                  {credentialsInvalid.phone ? (
                    <Text style={{ color: "red" }}>
                      Enter a Valid Phone Number (11 digits)
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Social Security Number: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.ssn && { borderColor: "red" },
                      { height: 60 },
                    ]}
                    onChangeText={setSsn}
                    value={ssn}
                    autoCapitalize="none"
                    keyboardType={"numeric"}
                  />
                  {credentialsInvalid.ssn ? (
                    <Text style={{ color: "red" }}>
                      This Field Cannot be empty
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text style={{ fontSize: 16 }}>Family Members: </Text>
                  <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.members && { borderColor: "red" },
                    ]}
                    onChangeText={setMembers}
                    value={members}
                    autoCapitalize="none"
                    keyboardType={"numeric"}
                  />
                  {credentialsInvalid.members ? (
                    <Text style={{ color: "red" }}>
                      This Field Cannot be empty
                    </Text>
                  ) : null}
                </View>
                <View style={{ paddingHorizontal: 20, paddingBottom: 20 }}>
                  <Text
                    style={[
                      { fontSize: 16 },
                      credentialsInvalid.agreement && { color: "red" },
                    ]}
                  >
                    Agreement:{" "}
                  </Text>
                  {/* <TextInput
                    style={[
                      styles.input,
                      credentialsInvalid.boxes && { borderColor: "red" },
                    ]}
                    onChangeText={setBoxes}
                    value={boxes}
                    autoCapitalize="none"
                  /> */}
                  <TouchableOpacity
                    style={styles.buttonStyle}
                    activeOpacity={0.5}
                    onPress={selectFile}
                  >
                    <Text style={styles.buttonTextStyle}>Select File</Text>
                  </TouchableOpacity>
                  {credentialsInvalid.agreement ? (
                    <Text style={{ color: "red" }}>
                      This Field Cannot be empty
                    </Text>
                  ) : null}
                </View>
                {agreement != null ? (
                  <Text style={styles.textStyle}>
                    File Name: {agreement.name ? agreement.name : ""}
                    {"\n"}
                    Type: {agreement.type ? agreement.type : ""}
                    {"\n"}
                    File Size: {agreement.size ? agreement.size : ""}
                    {"\n"}
                    URI: {agreement.uri ? agreement.uri : ""}
                    {"\n"}
                  </Text>
                ) : null}

                <Pressable
                  style={{
                    width: "90%",
                    alignSelf: "center",
                    marginTop: windowHeight * 0.02,
                    marginBottom: windowHeight * 0.05,
                  }}
                  onPress={() =>
                    submitHandler({
                      property: property,
                      name: name,
                      email: email,
                      phone: phone,
                      ssn: ssn,
                      members: members,
                      agreement: agreement,
                    })
                  }
                >
                  <View style={styles.button}>
                    <Text
                      style={{
                        color: "white",
                        alignSelf: "center",
                        fontSize: 17,
                      }}
                    >
                      Send
                    </Text>
                  </View>
                </Pressable>
              </ScrollView>
            </KeyboardAvoidingView>
          </View>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

export default BookProperty;

const styles = StyleSheet.create({
  centeredView: {
    // marginTop: '50%',
    flex: 1,
    backgroundColor: "#000000aa",
    justifyContent: "center",
    alignItems: "center",
  },
  modalView: {
    backgroundColor: "white",
    width: "95%",
    height: "95%",
    // padding: 20,
    // alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 10,
  },
  input: {
    height: 40,
    marginTop: windowHeight * 0.01,
    borderWidth: 1,
    borderColor: "lightgray",
    borderRadius: 4,
    padding: 7,
    fontSize: 17,
  },
  button: {
    padding: "3%",
    borderRadius: Platform.OS === "ios" ? "6%" : 6,
    backgroundColor: "#30CAA0",
  },
  buttonStyle: {
    backgroundColor: "#307ecc",
    borderWidth: 0,
    color: "#FFFFFF",
    borderColor: "#307ecc",
    height: 40,
    alignItems: "center",
    borderRadius: 30,
    marginLeft: 35,
    marginRight: 35,
    marginTop: 15,
  },
  buttonTextStyle: {
    color: "#FFFFFF",
    paddingVertical: 10,
    fontSize: 16,
  },
  textStyle: {
    backgroundColor: "#fff",
    fontSize: 15,
    marginTop: 16,
    marginLeft: 35,
    marginRight: 35,
    textAlign: "center",
  },
});
