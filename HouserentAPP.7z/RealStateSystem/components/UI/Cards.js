import {
  StyleSheet,
  View,
  Text,
  Image,
  Dimensions,
  Pressable,
} from "react-native";
import {
  Ionicons,
  AntDesign,
  FontAwesome,
  FontAwesome5,
} from "@expo/vector-icons";
import React from "react";
const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;

import { useNavigation } from "@react-navigation/native";
const Cards = ({ item }) => {
  const navigation = useNavigation();

  function convertDateToWeeksAndDays(dateString) {
    const hireDate = new Date(dateString);
    const now = new Date();

    const diffInMilliseconds = now - hireDate;
    const diffInDays = Math.floor(diffInMilliseconds / (1000 * 60 * 60 * 24));
    const diffInWeeks = Math.floor(diffInDays / 7);
    const remainingDays = diffInDays % 7;

    return `${diffInWeeks} weeks ${remainingDays} days`;
  }

  const hireDateStr = item.realtor.hire_date;
  const formattedDate = convertDateToWeeksAndDays(hireDateStr);

  return (
    <View style={styles.card}>
      <View>
        <Image
          source={{ uri: `${item.photo_main}` }}
          style={{
            resizeMode: "cover",
            height: 230,
          }}
        />
        <View
          style={{
            position: "absolute",
            backgroundColor: "#30CAA0",
            height: windowHeight * 0.04,
            justifyContent: "center",
            borderRadius: Platform.OS === "ios" ? "5%" : 5,
            marginTop: windowHeight * 0.02,
            marginLeft: windowWidth * 0.04,
            paddingHorizontal: windowWidth * 0.02,
          }}
        >
          <Text style={{ fontWeight: "bold", color: "white", fontSize: 17 }}>
            ${item.price}
          </Text>
        </View>
        <View style={{ alignItems: "center" }}>
          <Text
            style={{
              fontWeight: "bold",
              fontSize: 25,
              paddingVertical: windowHeight * 0.02,
            }}
          >
            {item.title}
          </Text>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: windowWidth * 0.02,
            }}
          >
            <Ionicons name="location-sharp" size={20} color="#30CAA0" />
            <Text style={{ fontSize: 15 }}>
              {item.city + " " + item.state + "," + item.zipcode}
            </Text>
          </View>
        </View>
        <View
          style={{
            width: windowWidth * 0.8,
            alignSelf: "center",
            borderBottomColor: "lightgray",
            borderBottomWidth: 1.2,
          }}
        />
        <View style={{ marginVertical: windowHeight * 0.03 }}>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",

              paddingHorizontal: windowWidth * 0.05,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <AntDesign name="windows" size={16} color="#30CAA0" />
              <Text
                style={{
                  color: "#30CAA0",
                  marginLeft: windowWidth * 0.006,
                  fontSize: 15,
                }}
              >
                Sqft:{item.sqft}
              </Text>
            </View>

            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
              }}
            >
              <FontAwesome name="car" size={16} color="#30CAA0" />
              <Text
                style={{
                  color: "#30CAA0",
                  marginLeft: windowWidth * 0.006,
                  fontSize: 15,
                  paddingRight: windowWidth * 0.06,
                }}
              >
                Garage: {item.garage}
              </Text>
            </View>
          </View>
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              paddingHorizontal: windowWidth * 0.05,
              paddingTop: windowHeight * 0.02,
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <FontAwesome5 name="bed" size={16} color="#30CAA0" />
              <Text
                style={{
                  color: "#30CAA0",
                  marginLeft: windowWidth * 0.006,
                  fontSize: 15,
                }}
              >
                Bedrooms:{item.bedrooms}
              </Text>
            </View>
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <FontAwesome5 name="bath" size={16} color="#30CAA0" />
              <Text
                style={{
                  color: "#30CAA0",
                  marginLeft: windowWidth * 0.006,
                  fontSize: 15,
                }}
              >
                Bathrooms:{item.bathrooms}
              </Text>
            </View>
          </View>
        </View>
        <View
          style={{
            width: windowWidth * 0.8,
            alignSelf: "center",
            borderBottomColor: "lightgray",
            borderBottomWidth: 1.2,
          }}
        />
        <View
          style={{
            marginVertical: windowHeight * 0.03,
            marginHorizontal: windowWidth * 0.04,
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center" }}>
            <Ionicons name="person" size={16} color="#30CAA0" />
            <Text
              style={{
                marginLeft: windowWidth * 0.006,
                color: "#30CAA0",
                fontSize: 16,
              }}
            >
              {item.realtor.name}
            </Text>
          </View>
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginTop: windowHeight * 0.02,
            }}
          >
            <AntDesign name="clockcircle" size={16} color="#30CAA0" />
            <Text
              style={{
                marginLeft: windowWidth * 0.006,
                color: "#30CAA0",
                fontSize: 16,
              }}
            >
              {formattedDate}
            </Text>
          </View>
        </View>
        <View
          style={{
            width: windowWidth * 0.8,
            alignSelf: "center",
            borderBottomColor: "lightgray",
            borderBottomWidth: 1.2,
          }}
        />
        <Pressable
          onPress={() => navigation.navigate("More Info", { item: item })}
          style={{
            width: "90%",
            alignSelf: "center",
            marginTop: windowHeight * 0.02,
            marginBottom: windowHeight * 0.03,
          }}
        >
          <View style={styles.button}>
            <Text
              style={{
                color: "white",
                alignSelf: "center",
                fontSize: 17,
              }}
            >
              More Info
            </Text>
          </View>
        </Pressable>
      </View>
    </View>
  );
};

export default Cards;

const styles = StyleSheet.create({
  card: {
    //  height: "100%",
    width: "100%",
    borderWidth: 1,
    borderColor: "lightgray",
    marginHorizontal: 4,
    marginVertical: 6,
  },
  button: {
    padding: "3%",
    borderRadius: Platform.OS === "ios" ? "6%" : 6,
    backgroundColor: "#10284E",
  },
});
