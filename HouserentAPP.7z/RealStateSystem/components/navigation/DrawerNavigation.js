import { StyleSheet, Text, View } from "react-native";
import React, { useContext } from "react";
import {
  createDrawerNavigator,
  DrawerContentScrollView,
  DrawerItemList,
  DrawerItem,
} from "@react-navigation/drawer";

import Home from "../../screens/Home";
import Aboutus from "../../screens/Aboutus";
import FeaturedListenings from "../../screens/FeaturedListenings";
import Register from "../../screens/Register";
import Login from "../../screens/Login";
import { AuthContext } from "../../store/auth-context";
import Dashboard from "../../screens/Dashboard";
import MyBookings from "../../screens/MyBookings";
import MyChat from "../../screens/MyChat";

const Drawer = createDrawerNavigator();

function CustomDrawerContent(props) {
  const authCtx = useContext(AuthContext);
  return (
    <DrawerContentScrollView {...props}>
      <DrawerItemList {...props} />
      {authCtx.isAuthenticated && (
        <DrawerItem
          label="Logout"
          onPress={() => {
            authCtx.logout();
          }}
        />
      )}
    </DrawerContentScrollView>
  );
}

const DrawerNavigation = () => {
  const authCtx = useContext(AuthContext);
  return (
    <Drawer.Navigator
      initialRouteName="Home"
      screenOptions={{
        headerTintColor: "white",
        headerStyle: { backgroundColor: "#2DABBE" },
        contentStyle: { backgroundColor: "white" },
        // drawerActiveBackgroundColor: "white",
        drawerStyle: {
          backgroundColor: "#2DABBE",
        },
        drawerActiveTintColor: "white",
        drawerInactiveTintColor: "#96D5DF",
      }}
      drawerContent={(props) => <CustomDrawerContent {...props} />}
    >
      <Drawer.Screen name="Home" component={Home} />
      {/* <Drawer.Screen name="About Us" component={Aboutus} /> */}
      <Drawer.Screen
        name="Featured Listenings"
        component={FeaturedListenings}
      />
      <Drawer.Screen name="Chat Bot" component={MyChat} />
      {!authCtx.isAuthenticated && (
        <Drawer.Screen name="Register" component={Register} />
      )}
      {!authCtx.isAuthenticated && (
        <Drawer.Screen name="Login" component={Login} />
      )}
      {authCtx.isAuthenticated && (
        <Drawer.Screen name="Dashboard" component={Dashboard} />
      )}
      {authCtx.isAuthenticated && (
        <Drawer.Screen name="My Bookings" component={MyBookings} />
      )}
    </Drawer.Navigator>
  );
};

export default DrawerNavigation;

const styles = StyleSheet.create({});
