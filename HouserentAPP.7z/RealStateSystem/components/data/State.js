export const state = [
  "",
  "Alaska",
  "Alabama",
  "Arkansas",
  "American Samoa",
  "Arizona",
  "California",
  "Colorado",
  "Connecticut",
  "District of Columbia",
  "Delaware",
  "Florida",
  "Georgia",
  "Guam",
  "Hawaii",
  "Iowa",
  "Idaho",
  "Illinois",
  "Kansas",
];

export const bedrooms = ["", 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

export const price = [
  1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000,
  10000
];
