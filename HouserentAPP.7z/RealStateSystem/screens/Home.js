import {
  StyleSheet,
  Text,
  View,
  Dimensions,
  TextInput,
  Pressable,
  ScrollView,
  VirtualizedList,
} from "react-native";
import React, { useState, useEffect } from "react";
const windowWidth = Dimensions.get("window").width;
const windowHeight = Dimensions.get("window").height;
import SelectDropdown from "react-native-select-dropdown";
import { state, bedrooms, price } from "../components/data/State";
import { AntDesign, FontAwesome } from "@expo/vector-icons";
import LoadingOverlay from "../components/UI/LoadingOverlay";
import Cards from "../components/UI/Cards";

const Home = () => {
  const [keyword, setKeyword] = useState("");
  const [city, setCity] = useState("");
  const [selectedState, SelectState] = useState("");
  const [EnteredBedrooms, SelectedBedrooms] = useState("");
  const [EnteredPrice, SelectedPrice] = useState("");
  const [data, setData] = useState([]);
  const [timeout, settime] = useState(true);
  const [isdata, setisdata] = useState(true);

  const [filteredData, setfilteredData] = useState([]);
  const [masterData, setmasterData] = useState([]);
  const [search, setsearch] = useState("");

  const fetchData = async () => {
    settime(true);
    try {
      const response = await fetch(
        "https://house-rent.herokuapp.com/listings/listing"
      );
      const data = await response.json();
      return data;
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    const getData = async () => {
      const data = await fetchData();
      console.log(data);
      setfilteredData(data);
      setmasterData(data);
      setData(data);
    };
    getData();
  }, []);

  const searchFilter = (text) => {
    let { keyword, city, selectedState, EnteredBedrooms, EnteredPrice } = text;

    const newData = masterData.filter((item) => {
      const itemTitle = item.title
        ? item.title.toUpperCase()
        : "".toUpperCase();
      const keywordText = keyword.toUpperCase();
      const itemCity = item.city ? item.city.toUpperCase() : "".toUpperCase();
      const cityText = city.toUpperCase();

      const itemState = item.state
        ? item.state.toUpperCase()
        : "".toUpperCase();
      const stateText = selectedState.toUpperCase();
      console.log(stateText);
      const itemBedroom = item.bedrooms ? item.bedrooms : "".toUpperCase();
      const BedroomText = EnteredBedrooms;
      const itemPrice = item.price ? parseInt(item.price) : 0;

      const maxPrice = EnteredPrice
        ? parseInt(EnteredPrice)
        : Number.MAX_SAFE_INTEGER;

      return (
        itemTitle.indexOf(keywordText) > -1 &&
        itemCity.indexOf(cityText) > -1 &&
        itemState.indexOf(stateText) > -1 &&
        (BedroomText !== "" && EnteredBedrooms
          ? itemBedroom === parseInt(EnteredBedrooms)
          : true) &&
        itemPrice <= maxPrice
      );
    });

    setfilteredData(newData);
    setsearch(keyword);
  };

  const renderItem = ({ item }) => {
    return (
      <View style={styles.container1}>
        <Cards item={item} />
      </View>
    );
  };
  const getItem = (data, index) => {
    return data[index];
  };

  return (
    <View style={styles.container}>
      <ScrollView alwaysBounceVertical={false} nestedScrollEnabled={true}>
        <View style={styles.box}>
          <Text
            style={{
              color: "white",
              fontSize: 25,
              textAlign: "center",
            }}
          >
            Property Searching {"\n"}Just Got So Easy
          </Text>
          <TextInput
            style={styles.input}
            onChangeText={setKeyword}
            value={keyword}
            placeholder="Keyword (Pool,Garage,etc)"
            autoCapitalize="none"
          />
          <TextInput
            style={styles.input}
            onChangeText={setCity}
            value={city}
            placeholder="City"
            autoCapitalize="none"
          />
          <SelectDropdown
            buttonStyle={[styles.input, { width: windowWidth * 0.72 }]}
            buttonTextStyle={{ textAlign: "left" }}
            defaultButtonText="State (All)"
            statusBarTranslucent={true}
            data={state}
            dropdownIconPosition={"right"}
            renderDropdownIcon={(isOpened) => {
              return (
                <FontAwesome
                  name={isOpened ? "chevron-up" : "chevron-down"}
                  color={"#444"}
                  size={18}
                />
              );
            }}
            onSelect={(selectedItem, index) => {
              SelectState(selectedItem);
              console.log(selectedItem, index);
            }}
            buttonTextAfterSelection={(selectedItem, index) => {
              return selectedItem;
            }}
            rowTextForSelection={(item, index) => {
              return item;
            }}
          />
          <SelectDropdown
            buttonStyle={[styles.input, { width: windowWidth * 0.72 }]}
            buttonTextStyle={{ textAlign: "left" }}
            defaultButtonText="Bedrooms (All)"
            statusBarTranslucent={true}
            data={bedrooms}
            dropdownIconPosition={"right"}
            renderDropdownIcon={(isOpened) => {
              return (
                <FontAwesome
                  name={isOpened ? "chevron-up" : "chevron-down"}
                  color={"#444"}
                  size={18}
                />
              );
            }}
            onSelect={(selectedItem, index) => {
              SelectedBedrooms(selectedItem);
              console.log(selectedItem, index);
            }}
            buttonTextAfterSelection={(selectedItem, index) => {
              return selectedItem;
            }}
            rowTextForSelection={(item, index) => {
              return item;
            }}
          />
          <SelectDropdown
            buttonStyle={[styles.input, { width: windowWidth * 0.72 }]}
            buttonTextStyle={{ textAlign: "left" }}
            defaultButtonText="Max Price (Any)"
            statusBarTranslucent={true}
            data={price}
            dropdownIconPosition={"right"}
            renderDropdownIcon={(isOpened) => {
              return (
                <FontAwesome
                  name={isOpened ? "chevron-up" : "chevron-down"}
                  color={"#444"}
                  size={18}
                />
              );
            }}
            onSelect={(selectedItem, index) => {
              SelectedPrice(selectedItem);
              console.log(selectedItem, index);
            }}
            buttonTextAfterSelection={(selectedItem, index) => {
              return selectedItem;
            }}
            rowTextForSelection={(item, index) => {
              return item;
            }}
          />
          <Pressable
            onPress={() => {
              searchFilter({
                keyword,
                city,
                selectedState,
                EnteredBedrooms,
                EnteredPrice,
              });
            }}
            style={{
              width: "100%",
              alignSelf: "center",
              marginTop: windowHeight * 0.04,
            }}
          >
            <View style={styles.button}>
              <Text
                style={{
                  color: "white",
                  alignSelf: "center",
                  fontSize: 17,
                }}
              >
                SUBMIT FORM
              </Text>
            </View>
          </Pressable>
        </View>
        <View>
          {data.length === 0 ? (
            <LoadingOverlay />
          ) : (
            <VirtualizedList
              data={filteredData}
              initialNumToRender={5}
              renderItem={renderItem}
              //onRefresh={}
              //  refreshing={timeout}
              keyExtractor={(item) => item.id}
              getItemCount={(data) => data.length}
              getItem={getItem}
            />
          )}
        </View>
      </ScrollView>
    </View>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  container1: {
    // height: 610,
    width: windowWidth * 0.9,
    alignSelf: "center",
    marginTop: windowHeight * 0.02,
  },
  box: {
    backgroundColor: "#00008B",
    width: windowWidth * 0.9,
    // height: windowHeight * 0.7,
    alignSelf: "center",
    marginTop: windowHeight * 0.04,
    padding: windowHeight * 0.05,
  },
  input: {
    height: 40,
    marginTop: windowHeight * 0.02,
    borderWidth: 1,
    borderColor: "lightgray",
    borderRadius: 4,
    padding: 7,
    backgroundColor: "white",
  },
  button: {
    padding: "3%",
    borderRadius: Platform.OS === "ios" ? "6%" : 6,
    backgroundColor: "#E94646",
  },
});
